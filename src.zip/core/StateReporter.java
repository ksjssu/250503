package core;

import java.io.PrintWriter;
import java.io.IOException;
import java.net.Socket;
import org.json.JSONObject;

public class StateReporter {
    private static PrintWriter writer;

    /**
     * Initialize socket writer for state channel
     */
    public static void setSocket(Socket s) {

        try {
            writer = new PrintWriter(s.getOutputStream(), true);
            System.out.println("[Socket][JAVA]  STATE socket connected to Python on " + s.getRemoteSocketAddress());
        } catch (IOException e) {
            System.err.println("StateReporter setSocket error: " + e.getMessage());
        }
    }

    /**
     * Send environment state as JSON to Python side
     */
    public static void sendState(double bufferOccupancy, int messageCount, double successRate) {
        try {
            JSONObject json = new JSONObject();
            json.put("buffer_occupancy", bufferOccupancy);
            json.put("message_count", messageCount);
            json.put("success_rate", successRate);
            writer.println(json.toString());
        } catch (Exception e) {
            System.err.println("StateReporter sendState error: " + e.getMessage());
        }
    }

    /**
     * Send termination signal to Python side
     */
    public static void sendDone() {
        if (writer != null) {
            writer.println("done");
            writer.flush();
        }
    }

    /**
     * Close writer and release socket
     */
    public static void close() {
        if (writer != null) {
            writer.close();
        }
    }
}
