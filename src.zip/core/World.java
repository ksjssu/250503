package core;

import input.EventQueue;
import input.ExternalEvent;
import input.ScheduledUpdatesQueue;
import report.MessageStatsReport;
import routing.BufferAwareProphetRouter;

import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class World {
    private static final String HOST = "localhost";
    private static final int STATE_PORT = 50051;
    private static final int ACTION_PORT = 50052;

    // Counts how many update() calls have occurred
    private int updateCount = 0;

    private int sizeX;
    private int sizeY;
    private List<EventQueue> eventQueues;
    private double updateInterval;
    private SimClock simClock;
    private double nextQueueEventTime;
    private EventQueue nextEventQueue;
    private List<DTNHost> hosts;
    private boolean simulateConnections;
    private ArrayList<DTNHost> updateOrder;
    private boolean isCancelled;
    private List<UpdateListener> updateListeners;
    private ScheduledUpdatesQueue scheduledUpdates;
    private boolean simulateConOnce;

    public static final String OPTIMIZATION_SETTINGS_NS = "Optimization";
    public static final String RANDOMIZE_UPDATES_S = "randomizeUpdateOrder";
    public static final boolean DEF_RANDOMIZE_UPDATES = true;
    public static final String SIMULATE_CON_ONCE_S = "simulateConnectionsOnce";

    public World(List<DTNHost> hosts, int sizeX, int sizeY,
                 double updateInterval, List<UpdateListener> updateListeners,
                 boolean simulateConnections, List<EventQueue> eventQueues) {
        this.hosts = hosts;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.updateInterval = updateInterval;
        this.updateListeners = updateListeners;
        this.simulateConnections = simulateConnections;
        this.eventQueues = eventQueues;
        this.simClock = SimClock.getInstance();
        this.scheduledUpdates = new ScheduledUpdatesQueue();
        this.isCancelled = false;
        setNextEventQueue();
        initSettings();
    }

    private void initSettings() {
        Settings s = new Settings(OPTIMIZATION_SETTINGS_NS);
        boolean randomizeUpdates = DEF_RANDOMIZE_UPDATES;
        if (s.contains(RANDOMIZE_UPDATES_S)) {
            randomizeUpdates = s.getBoolean(RANDOMIZE_UPDATES_S);
        }
        simulateConOnce = s.getBoolean(SIMULATE_CON_ONCE_S, false);
        if (randomizeUpdates) {
            this.updateOrder = new ArrayList<DTNHost>(this.hosts);
        } else {
            this.updateOrder = null;
        }
    }

    public void warmupMovementModel(double time) {
        if (time <= 0) {
            return;
        }
        while (SimClock.getTime() < -updateInterval) {
            moveHosts(updateInterval);
            simClock.advance(updateInterval);
        }
        double finalStep = -SimClock.getTime();
        moveHosts(finalStep);
        simClock.setTime(0);
    }

    public void setNextEventQueue() {
        EventQueue nextQueue = scheduledUpdates;
        double earliest = nextQueue.nextEventsTime();
        for (EventQueue eq : eventQueues) {
            if (eq.nextEventsTime() < earliest) {
                nextQueue = eq;
                earliest = eq.nextEventsTime();
            }
        }
        this.nextEventQueue = nextQueue;
        this.nextQueueEventTime = earliest;
    }

    public void update() {
        double runUntil = SimClock.getTime() + this.updateInterval;
        setNextEventQueue();
        while (this.nextQueueEventTime <= runUntil) {
            simClock.setTime(this.nextQueueEventTime);
            ExternalEvent ee = this.nextEventQueue.nextEvent();
            ee.processEvent(this);
            updateHosts();
            setNextEventQueue();
        }
        moveHosts(this.updateInterval);
        simClock.setTime(runUntil);
        updateHosts();
        for (UpdateListener ul : this.updateListeners) {
            ul.updated(this.hosts);
        }

        // Increment update count and perform handshake every 300 updates
        updateCount++;
        if (updateCount % 300 == 0) {
      
            DTNHost h0 = hosts.get(0);
            StateReporter.sendState(
                h0.getBufferOccupancy(),
                h0.getNrofMessages(),
                MessageStatsReport.getLatestDeliveryProb()
            );

          
            ActionReceiver.Action act = ActionReceiver.receiveAction();
            if (act != null) {
       
                for (DTNHost h : hosts) {
                    if (h.getRouter() instanceof BufferAwareProphetRouter) {
                        BufferAwareProphetRouter r =
                            (BufferAwareProphetRouter) h.getRouter();
                        r.updateAlpha(act.alpha);
                        r.updateTrendWindow(act.trendWindow);
                    }
                }
            }
        }
    }

    private void updateHosts() {
        if (this.updateOrder == null) {
            for (int i = 0; i < hosts.size(); i++) {
                if (this.isCancelled) {
                    break;
                }
                hosts.get(i).update(simulateConnections);
            }
        } else {
            assert this.updateOrder.size() == this.hosts.size();
            Random rng = new Random(SimClock.getIntTime());
            Collections.shuffle(this.updateOrder, rng);
            for (int i = 0; i < hosts.size(); i++) {
                if (this.isCancelled) {
                    break;
                }
                this.updateOrder.get(i).update(simulateConnections);
            }
        }
        if (simulateConOnce && simulateConnections) {
            simulateConnections = false;
        }
    }

    private void moveHosts(double timeIncrement) {
        for (int i = 0; i < hosts.size(); i++) {
            DTNHost host = hosts.get(i);
            host.move(timeIncrement);
        }
    }

    public void cancelSim() {
        this.isCancelled = true;
    }

    public List<DTNHost> getHosts() {
        return this.hosts;
    }

    public int getSizeX() {
        return this.sizeX;
    }

    public int getSizeY() {
        return this.sizeY;
    }

    public DTNHost getNodeByAddress(int address) {
        if (address < 0 || address >= hosts.size()) {
            throw new SimError("No host for address " + address +
                ". Address range of 0-" + (hosts.size()-1) + " is valid");
        }
        DTNHost node = this.hosts.get(address);
        assert node.getAddress() == address;
        return node;
    }

    public void scheduleUpdate(double simTime) {
        scheduledUpdates.addUpdate(simTime);
    }

    public void beginSimulation() {
        Socket stateSock = null;
        Socket actionSock = null;
        try {
        	System.out.println("[World] Connecting to Python STATE port " + STATE_PORT + "...");
            stateSock = new Socket(HOST, STATE_PORT);
            System.out.println("[World] Connecting to Python ACTION port " + ACTION_PORT + "...");
            actionSock = new Socket(HOST, ACTION_PORT);
            StateReporter.setSocket(stateSock);
            ActionReceiver.setSocket(actionSock);
        } catch (IOException e) {
            System.err.println("beginSimulation error: " + e.getMessage());
        }
    }

    public void endSimulation() {
        StateReporter.sendDone();
        StateReporter.close();
        ActionReceiver.close();
    }
}
