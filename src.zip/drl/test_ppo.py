import os
import subprocess
import time

from dtn_env import CdtnEnvContinuous
from ppo_agent import PPOAgent
import config
import utils

# 5M 단위로 5M부터 50M까지
BUFFER_SIZES = [f"{i}M" for i in range(5, 51, 5)]
# 시드는 1,2,3,4 각 10회씩
SEEDS = [1, 2, 3, 4]
EPISODES = len(BUFFER_SIZES) * len(SEEDS)  # 10 * 4 = 40

# 경로 설정
CUR_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_SRC = os.path.dirname(CUR_DIR)

# Java 클래스패스용 JAR 목록 준비
LIB_DIR = os.path.join(PROJECT_SRC, 'lib')
jar_names = ['json.jar', 'ECLA.jar', 'DTNConsoleConnection.jar']
LIB_JARS = [os.path.join(LIB_DIR, j) for j in jar_names]
CP_SEP = ';' if os.name == 'nt' else ':'
CP = CP_SEP.join([PROJECT_SRC] + LIB_JARS)

# 기본 DTNSim 실행 커맨드 (배치 모드 1회 실행)
BASE_JAVA_CMD = [
    'java', '-Xmx512M',
    '-cp', CP,
    'core.DTNSim',
    '-b', '1'
]

# override 설정 파일 경로
OVERRIDE_CONF = os.path.join(PROJECT_SRC, 'override_settings.txt')

def main():
    # 에이전트 생성 및 체크포인트 로드
    agent = PPOAgent(
        config.STATE_DIM, config.ACTION_DIM,
        config.LR_ACTOR, config.LR_CRITIC,
        config.GAMMA, config.K_EPOCHS, config.EPS_CLIP
    )
    utils.load_model(agent, 'ppo_dtn.pth')

    for ep in range(1, EPISODES + 1):
        # 어떤 시드를 쓸지, 어느 버퍼 사이즈를 쓸지 결정
        seed = SEEDS[(ep - 1) // len(BUFFER_SIZES)]
        buf_size = BUFFER_SIZES[(ep - 1) % len(BUFFER_SIZES)]

        # override 파일에 시드, 버퍼, 에피소드 번호 기록
        with open(OVERRIDE_CONF, 'w') as f:
            f.write(f"MovementModel.rngSeed = {seed}\n")
            f.write(f"Group.bufferSize = {buf_size}\n")
            f.write(f"number = {ep}\n")

        # DTNSim 실행
        java_cmd = BASE_JAVA_CMD + [
            'default_settings.txt',
            OVERRIDE_CONF
        ]
        print(f"▶ 에피소드 {ep} 시작 | seed={seed} | bufferSize={buf_size}")
        proc = subprocess.Popen(java_cmd, cwd=PROJECT_SRC)
        time.sleep(2)  # 소켓 연결 대기

        # 환경 초기화
        env = CdtnEnvContinuous()
        state = env.reset()
        total_reward = 0.0
        step_count = 0

        # 한 에피소드 실행
        while True:
            action = agent.select_action(state)
            next_state, reward, done, _ = env.step(action)
            state = next_state
            total_reward += reward
            step_count += 1
            if done or step_count >= config.MAX_STEPS:
                break

        # 종료 대기 및 정리
        proc.wait()
        env.close()

        print(f"✔ 에피소드 {ep} 완료 | steps={step_count} | reward={total_reward:.2f}\n")

if __name__ == '__main__':
    main()
