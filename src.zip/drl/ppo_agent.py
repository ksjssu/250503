# ppo_agent.py

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from torch.distributions import Beta
import config

class Actor(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        # 공유된 feature extractor
        self.shared = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.ReLU(),
        )
        # Beta concentration 파라미터
        self.alpha_a_head = nn.Linear(64, 1)
        self.alpha_b_head = nn.Linear(64, 1)
        self.trend_a_head = nn.Linear(64, 1)
        self.trend_b_head = nn.Linear(64, 1)

    def forward(self, x):
        h = self.shared(x)
        # raw logits
        raw_a1 = torch.clamp(self.alpha_a_head(h), -10.0, 10.0)
        raw_b1 = torch.clamp(self.alpha_b_head(h), -10.0, 10.0)
        raw_a2 = torch.clamp(self.trend_a_head(h), -10.0, 10.0)
        raw_b2 = torch.clamp(self.trend_b_head(h), -10.0, 10.0)
        # softplus로 >0 만들고 +1
        alpha_a = torch.nn.functional.softplus(raw_a1) + 1.0
        alpha_b = torch.nn.functional.softplus(raw_b1) + 1.0
        trend_a = torch.nn.functional.softplus(raw_a2) + 1.0
        trend_b = torch.nn.functional.softplus(raw_b2) + 1.0
        # (batch,4)
        params = torch.cat([alpha_a, alpha_b, trend_a, trend_b], dim=-1)
        return params

    def sample(self, params):
        # params: (batch,4)
        a1, b1, a2, b2 = torch.split(params, 1, dim=-1)
        # squeeze to (batch,)
        a1 = a1.squeeze(-1)
        b1 = b1.squeeze(-1)
        a2 = a2.squeeze(-1)
        b2 = b2.squeeze(-1)
        # Beta distribution
        dist1 = Beta(a1, b1)
        dist2 = Beta(a2, b2)
        alpha = dist1.rsample()       # [0,1]
        trend_norm = dist2.rsample()  # [0,1]
        return alpha, trend_norm, dist1, dist2

class Critic(nn.Module):
    def __init__(self, state_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

    def forward(self, x):
        return self.net(x)

class PPOAgent:
    def __init__(self,
                 state_dim,
                 action_dim,
                 lr_actor,
                 lr_critic,
                 gamma,
                 K_epochs,
                 eps_clip):
        self.gamma    = gamma
        self.K_epochs = K_epochs
        self.eps_clip = eps_clip

        self.actor  = Actor(state_dim, action_dim)
        self.critic = Critic(state_dim)

        self.opt_actor  = optim.Adam(self.actor.parameters(),  lr=lr_actor)
        self.opt_critic = optim.Adam(self.critic.parameters(), lr=lr_critic)

        # 메모리: (s, a, logp, r, s_, done)
        self.memory = []

    def select_action(self, state):
        s = torch.FloatTensor(state).unsqueeze(0)
        with torch.no_grad():
            params = self.actor(s)
        alpha, trend_norm, dist1, dist2 = self.actor.sample(params)
        # 스케일링 [0,1] -> [3,45]
        trend = 3.0 + (45.0 - 3.0) * trend_norm
        action = torch.stack([alpha, trend], dim=-1).squeeze(0)
        # 로그확률
        logprob = dist1.log_prob(alpha).sum() + dist2.log_prob(trend_norm).sum()
        return action.cpu().numpy(), logprob.item()

    def store_transition(self, s, a, logp, r, s_, done):
        self.memory.append((s, a, logp, r, s_, done))

    def train(self):
        if not self.memory:
            return

        states, actions, old_logps, rewards, next_states, dones = zip(*self.memory)
        states      = torch.FloatTensor(np.stack(states))      # list -> ndarray -> tensor
        actions     = torch.FloatTensor(actions)
        old_logps   = torch.FloatTensor(old_logps).unsqueeze(1)
        rewards     = torch.FloatTensor(rewards).unsqueeze(1)
        next_states = torch.FloatTensor(np.stack(next_states))
        dones       = torch.FloatTensor(dones).unsqueeze(1)

        # 타겟과 어드밴티지
        with torch.no_grad():
            values_next = self.critic(next_states)
            targets      = rewards + self.gamma * values_next * (1 - dones)
            advantages   = targets - self.critic(states)

        # PPO 업데이트
        for _ in range(self.K_epochs):
            params = self.actor(states)
            alpha, trend_norm, dist1, dist2 = self.actor.sample(params)
            # 스케일된 액션
            action_stack = torch.stack([alpha, 3.0 + (45.0-3.0)*trend_norm], dim=-1)

            logps   = dist1.log_prob(alpha).unsqueeze(1) + dist2.log_prob(trend_norm).unsqueeze(1)
            entropy = dist1.entropy().mean() + dist2.entropy().mean()

            ratios = torch.exp(logps - old_logps.detach())
            surr1  = ratios * advantages
            surr2  = torch.clamp(ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages
            loss_actor  = -torch.min(surr1, surr2).mean() - 0.01 * entropy

            values      = self.critic(states)
            loss_critic = nn.MSELoss()(values, targets)

            self.opt_actor.zero_grad()
            loss_actor.backward()
            self.opt_actor.step()

            self.opt_critic.zero_grad()
            loss_critic.backward()
            self.opt_critic.step()

        self.memory.clear()