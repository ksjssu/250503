package core;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject; // 

/**

 */
public class CommunicationBridge implements Runnable {

    private int port;
    private World world;
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private PrintWriter out;
    private BufferedReader in;
    private volatile boolean running = true;

    /**
     
     */
    public CommunicationBridge(World world, int port) {
        this.world = world;
        this.port = port;
    }

    /**
     *
     */
    @Override
    public void run() {
        try {
            serverSocket = new ServerSocket(port);
            System.out.println("CommunicationBridge: Waiting for external DRL agent connection on port " + port);
            clientSocket = serverSocket.accept();
            System.out.println("CommunicationBridge: DRL agent connected from " + clientSocket.getInetAddress());
            out = new PrintWriter(clientSocket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

          
            while (running) {
                // 1. create state data by json
                String stateJson = getStateJson();
                // 2. state data to agent
                out.println(stateJson);

                // 3. receive action data from agent
                if (in.ready()) {
                    String actionLine = in.readLine();
                    if (actionLine != null && !actionLine.trim().isEmpty()) {
                        System.out.println("CommunicationBridge: Received action: " + actionLine);
                        processAction(actionLine);
                    }
                }

                // 4. wait until update
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    // if interrupted, roof is ended
                    running = false;
                }
            }
        } catch (IOException e) {
            System.err.println("CommunicationBridge: I/O Error: " + e.getMessage());
        } finally {
            cleanup();
        }
    }

    /**
     
     */
    private String getStateJson() {
        JSONObject state = new JSONObject();
        state.put("time", SimClock.getTime());

        JSONArray hostsArray = new JSONArray();
        List<DTNHost> hosts = world.getHosts();
        
        if (hosts != null) {
            for (DTNHost host : hosts) {
                JSONObject hostJson = new JSONObject();
                hostJson.put("address", host.getAddress());

                JSONObject loc = new JSONObject();
                if (host.getLocation() != null) {
                    loc.put("x", host.getLocation().getX());
                    loc.put("y", host.getLocation().getY());
                } else {
                    loc.put("x", 0);
                    loc.put("y", 0);
                }
                hostJson.put("location", loc);

                // plus speed state
                if (host.getMovementModel() != null) {
                    hostJson.put("speed", host.getMovementModel().generateSpeed());
                } else {
                    hostJson.put("speed", 0);
                }

                hostsArray.put(hostJson);
            }
        }
        state.put("hosts", hostsArray);

        return state.toString(4); // 
    }

    /**
    
     */
    private void processAction(String actionLine) {

        String[] tokens = actionLine.trim().split("\\s+");
        if (tokens.length < 4) {
            System.err.println("CommunicationBridge: Invalid action command: " + actionLine);
            return;
        }

        String command = tokens[0];
        if ("setLocation".equalsIgnoreCase(command)) {
            try {
                int hostId = Integer.parseInt(tokens[1]);
                double x = Double.parseDouble(tokens[2]);
                double y = Double.parseDouble(tokens[3]);

           
                DTNHost host = world.getNodeByAddress(hostId);
                host.setLocation(new Coord(x, y));
                System.out.println("CommunicationBridge: Set location of host " + hostId +
                        " to (" + x + "," + y + ")");
            } catch (NumberFormatException e) {
                System.err.println("CommunicationBridge: Error parsing numbers in action: " + actionLine);
            } catch (SimError e) {
                System.err.println("CommunicationBridge: Error processing action: " + e.getMessage());
            }
        } else {
            System.err.println("CommunicationBridge: Unknown command: " + command);
        }
    }


    private void cleanup() {
        try {
            if (in != null) { in.close(); }
            if (out != null) { out.close(); }
            if (clientSocket != null) { clientSocket.close(); }
            if (serverSocket != null) { serverSocket.close(); }
        } catch (IOException e) {
            System.err.println("CommunicationBridge: Error during cleanup: " + e.getMessage());
        }
    }


    public void stop() {
        running = false;
    }
}
