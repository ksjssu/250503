package core;
import gui.DTNSimGUI;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import ui.DTNSimTextUI;

/**
 * Simulator's main class
 */
public class DTNSim {
    static int commPort = 5000;

    public static final String BATCH_MODE_FLAG = "-b";
    public static final String RANGE_DELIMETER = ":";
    public static final String RESET_METHOD_NAME = "reset";
    private static List<Class<?>> resetList = new ArrayList<Class<?>>();

    public static void main(String[] args) {
        boolean batchMode = false;
        int nrofRuns[] = {0,1};
        String confFiles[];
        int firstConfIndex = 0;
        int guiIndex = 0;

        java.util.Locale.setDefault(java.util.Locale.US);
        if (args.length > 0 && args[0].equals(BATCH_MODE_FLAG)) {
            batchMode = true;
            if (args.length == 1) {
                firstConfIndex = 1;
            } else {
                nrofRuns = parseNrofRuns(args[1]);
                firstConfIndex = 2;
            }
            confFiles = args;
        } else {
            // GUI mode or no args
            try {
                guiIndex = Integer.parseInt(args[0]);
                firstConfIndex = 1;
            } catch (Exception e) {
                firstConfIndex = 0;
            }
            confFiles = args.length > 0 ? args : new String[]{null};
        }

        initSettings(confFiles, firstConfIndex);

        if (batchMode) {
            long startTime = System.currentTimeMillis();
            for (int i = nrofRuns[0]; i < nrofRuns[1]; i++) {
                print("Run " + (i+1) + "/" + nrofRuns[1]);
                Settings.setRunIndex(i);
                resetForNextRun();
                SimScenario scenario = SimScenario.getInstance();
                World world = scenario.getWorld();
                world.beginSimulation();

                CommunicationBridge bridge = new CommunicationBridge(world, commPort);
                Thread bridgeThread = new Thread(bridge);
                bridgeThread.start();

                new DTNSimTextUI().start();

                world.endSimulation();
                bridge.stop();
                try {
                    bridgeThread.join();
                } catch (InterruptedException e) {
                    System.err.println("Bridge thread join interrupted: " + e.getMessage());
                }
            }
            double duration = (System.currentTimeMillis() - startTime) / 1000.0;
            print("---\nAll done in " + String.format("%.2f", duration) + "s");
            System.exit(0);
        } else {
            Settings.setRunIndex(guiIndex);
            SimScenario scenario = SimScenario.getInstance();
            World world = scenario.getWorld();
            world.beginSimulation();

            CommunicationBridge bridge = new CommunicationBridge(world, commPort);
            Thread bridgeThread = new Thread(bridge);
            bridgeThread.start();

            new DTNSimGUI().start();

            world.endSimulation();
            bridge.stop();
            try {
                bridgeThread.join();
            } catch (InterruptedException e) {
                System.err.println("Bridge thread join interrupted: " + e.getMessage());
            }
            System.exit(0);
        }
    }

    private static void initSettings(String[] confFiles, int firstIndex) {
        int i = firstIndex;
        if (i >= confFiles.length) return;
        try {
            Settings.init(confFiles[i]);
            for (i = firstIndex + 1; i < confFiles.length; i++) {
                Settings.addSettings(confFiles[i]);
            }
        } catch (SettingsError er) {
            try {
                Integer.parseInt(confFiles[i]);
            } catch (NumberFormatException nfe) {
                System.err.println("Failed to load settings: " + er);
                System.err.println("Caught at " + er.getStackTrace()[0]);
                System.exit(-1);
            }
            System.err.println("Warning: using deprecated run index format.");
            System.exit(-1);
        }
    }

    public static void registerForReset(String className) {
        try {
            Class<?> c = Class.forName(className);
            c.getMethod(RESET_METHOD_NAME);
            resetList.add(c);
        } catch (Exception e) {
            System.err.println("Can't register class " + className + ": " + e.getMessage());
            System.exit(-1);
        }
    }

    private static int[] parseNrofRuns(String arg) {
        int val[] = {0,1};
        if (arg.contains(RANGE_DELIMETER)) {
            val[0] = Integer.parseInt(arg.substring(0, arg.indexOf(RANGE_DELIMETER))) - 1;
            val[1] = Integer.parseInt(arg.substring(arg.indexOf(RANGE_DELIMETER)+1));
        } else {
            val[1] = Integer.parseInt(arg);
        }
        if (val[0] < 0 || val[0] >= val[1]) {
            System.err.println("Invalid run range: " + arg);
            System.exit(-1);
        }
        return val;
    }

    public static void resetForNextRun() {
        for (Class<?> c : resetList) {
            try {
                Method m = c.getMethod(RESET_METHOD_NAME);
                m.invoke(null);
            } catch (Exception e) {
                System.err.println("Failed to reset class " + c.getName());
                e.printStackTrace();
                System.exit(-1);
            }
        }
    }

    private static void print(String txt) {
        System.out.println(txt);
    }
}
