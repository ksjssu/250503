package core;
import java.net.Socket;
import java.io.IOException;

public class SocketClient {
    public static void main(String[] args) {
        Socket stateSock = null;
        Socket actionSock = null;
        try {
            stateSock = new Socket("localhost", 50051);
            actionSock = new Socket("localhost", 50052);
            StateReporter.setSocket(stateSock);
            ActionReceiver.setSocket(actionSock);
            StateReporter.sendState(0.76, 45.5, 0.88, 0.12, 0.15);
            ActionReceiver.Action act = ActionReceiver.receiveAction();
            if (act != null) {
                System.out.println("alpha=" + act.alpha);
                System.out.println("trendWindow=" + act.trendWindow);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try { StateReporter.close(); } catch (Exception ignore) {}
            try { ActionReceiver.close(); } catch (Exception ignore) {}
            try { if (stateSock != null) stateSock.close(); } catch (IOException ignore) {}
            try { if (actionSock != null) actionSock.close(); } catch (IOException ignore) {}
        }
    }
}