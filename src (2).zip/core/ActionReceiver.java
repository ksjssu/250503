package core;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.Socket;
import org.json.JSONObject;

public class ActionReceiver {
    private static BufferedReader reader;
    public static void setSocket(Socket s) {
        try {
            reader = new BufferedReader(new InputStreamReader(s.getInputStream()));
            System.out.println("[Socket][JAVA]  ACTION socket connected to Python on " + s.getRemoteSocketAddress());
        } catch (IOException e) {
            System.err.println("ActionReceiver setSocket error: " + e.getMessage());
        }
    }
        
    public static Action receiveAction() {
        try {
            String line = reader.readLine();
            if (line == null || line.trim().isEmpty()) {
                System.err.println("ActionReceiver no input");
                return null;
            }
            JSONObject json = new JSONObject(line);
            double alpha = json.getDouble("alpha");
            int trendWindow = json.getInt("trend_window");
            return new Action(alpha, trendWindow);
        } catch (Exception e) {
            System.err.println("ActionReceiver receiveAction error: " + e.getMessage());
            return null;
        }
    }
    public static void close() {
        try {
            if (reader != null) {
                reader.close();
            }
        } catch (IOException e) {
            System.err.println("ActionReceiver close error: " + e.getMessage());
        }
    }
    public static class Action {
        public final double alpha;
        public final int trendWindow;
        public Action(double alpha, int trendWindow) {
            this.alpha = alpha;
            this.trendWindow = trendWindow;
        }
    }
}