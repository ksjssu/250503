
import socket
import json
import numpy as np
import config

class SocketManager:
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind((config.HOST, config.PORT))
        self.sock.listen(1)
        print(f"[Socket] Listening on {config.HOST}:{config.PORT}")
        self.conn, _ = self.sock.accept()
        print("[Socket] ✅ Java connected.")

    def receive_state(self):
        try:
            line = self.conn.recv(1024).decode().strip()
            if not line:
                return None
            msg = json.loads(line)
            state = [msg.get("buffer_occupancy", 0.0),
                     msg.get("message_count", 0.0),
                     msg.get("success_rate", 0.0)]
            return np.array(state, dtype=np.float32)
        except Exception as e:
            print("[Socket] ❌ Error receiving state:", e)
            return None

    def send_action(self, action):
        try:
            action_msg = {
                "alpha": float(np.clip(action[0], 0.0, 1.0)),
                "trend_window": int(np.clip(action[1], 1, 100))
            }
            self.conn.sendall((json.dumps(action_msg) + "\n").encode("utf-8"))
        except Exception as e:
            print("[Socket] ❌ Error sending action:", e)

    def close(self):
        self.conn.close()
        self.sock.close()
