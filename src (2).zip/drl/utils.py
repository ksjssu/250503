import torch

def save_model(agent, filename):
    torch.save({
        'actor': agent.actor.state_dict(),
        'critic': agent.critic.state_dict()
    }, filename)


def load_model(agent, filename):
    try:
        # strict=False로 불일치 키 무시
        cp = torch.load(filename, weights_only=True)
        agent.actor.load_state_dict(cp['actor'], strict=False)
        agent.critic.load_state_dict(cp['critic'], strict=False)
        print(f"Loaded model from {filename} (with strict=False)")
    except FileNotFoundError:
        print(f"Checkpoint {filename} not found. Starting fresh.")
    except Exception as e:
        print(f"Warning: could not load full state_dict: {e}. Continuing with partial load.")
