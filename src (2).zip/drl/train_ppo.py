import os
import subprocess
import time
import random

from dtn_env import CdtnEnvContinuous
from ppo_agent import PPOAgent
import config
import utils

# Buffer sizes to cycle through each episode
BUFFER_SIZES = ["5M","10M","15M","20M","25M","30M", "35M", "40M", "45M", "50M"]

# 트렌드 성공률 기반 보상/페널티 값
SUCCESS_REWARD = 50
SUCCESS_PENALTY = -50

# 에피소드별 최소/최대 성공률 추적
global_min_succ = float('inf')
global_max_succ = float('-inf')

# Paths
CUR_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_SRC = os.path.dirname(CUR_DIR)

# Prepare Java classpath with the required JARs
LIB_DIR = os.path.join(PROJECT_SRC, 'lib')
jar_names = ['json.jar', 'ECLA.jar', 'DTNConsoleConnection.jar']
LIB_JARS = [os.path.join(LIB_DIR, name) for name in jar_names]
CP_SEP = ';' if os.name == 'nt' else ':'
CP = CP_SEP.join([PROJECT_SRC] + LIB_JARS)

# Base Java command for batch mode with a single run
BASE_JAVA_CMD = [
    'java',
    '-Xmx512M',
    '-cp', CP,
    'core.DTNSim',
    '-b', '1'
]

# Temporary override configuration file
OVERRIDE_CONF = os.path.join(PROJECT_SRC, 'override_settings.txt')


def main():
    global global_min_succ, global_max_succ

    # Initialize PPO agent and load checkpoint if available
    agent = PPOAgent(
        config.STATE_DIM, config.ACTION_DIM,
        config.LR_ACTOR, config.LR_CRITIC,
        config.GAMMA, config.K_EPOCHS, config.EPS_CLIP,
        max_episodes=config.MAX_EPISODES,
        max_scale=10.0
    )
    utils.load_model(agent, 'ppo_dtn.pth')

    # Training loop over episodes
    for ep in range(1, config.MAX_EPISODES + 1):
        # 1) Generate a random seed for this episode
        seed = random.randint(0, 10_000_000)
        # 2) Select buffer size in a round-robin fashion
        buf_size = BUFFER_SIZES[(ep - 1) % len(BUFFER_SIZES)]

        # 3) Write override settings (seed and buffer size)
        with open(OVERRIDE_CONF, 'w') as f:
            f.write(f"MovementModel.rngSeed = {seed}\n")
            f.write(f"Group.bufferSize = {buf_size}\n")

        # 4) Launch Java simulator with default and override settings
        java_cmd = BASE_JAVA_CMD + [
            'default_settings.txt',
            OVERRIDE_CONF
        ]
        print(f"▶ Episode {ep} start | seed={seed} | bufferSize={buf_size}")
        proc = subprocess.Popen(java_cmd, cwd=PROJECT_SRC)
        time.sleep(2)  # Wait for simulator sockets to open

        # 5) Initialize the Gym environment and run the episode
        env = CdtnEnvContinuous()
        state = env.reset()
        total_reward = 0.0
        step_count = 0

        while True:
            action, logprob = agent.select_action(state)
            next_state, reward, done, _ = env.step(action)
            agent.store_transition(state, action, logprob, reward, next_state, done)
            state = next_state
            total_reward += reward
            step_count += 1
            if done or step_count >= config.MAX_STEPS:
                break

        # 6) 에피소드 성공률 기반 보너스 계산
        episode_success = state[2]  # 마지막 상태의 success_rate
        bonus = 0.0
        if episode_success < global_min_succ:
            bonus = SUCCESS_PENALTY
            global_min_succ = episode_success
        elif episode_success > global_max_succ:
            bonus = SUCCESS_REWARD
            global_max_succ = episode_success

        # 마지막 transition 보상에 보너스 추가
        if agent.memory:
            s, a, lp, r, s_, done_flag = agent.memory[-1]
            agent.memory[-1] = (s, a, lp, r + bonus, s_, done_flag)
        print(f"Episode {ep} success={episode_success:.3f} bonus={bonus:.3f} min_succ={global_min_succ:.3f} max_succ={global_max_succ:.3f}")

        # 7) PPO 업데이트 및 모델 저장
        agent.train()
        utils.save_model(agent, 'ppo_dtn.pth')

        # 8) Java 프로세스 종료 대기 및 환경 닫기
        proc.wait()
        env.close()

        print(f"✔ Episode {ep} done | steps={step_count} | total_reward={total_reward:.2f}\n")


if __name__ == '__main__':
    main()
