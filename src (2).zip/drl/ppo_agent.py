# ppo_agent.py

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from torch.distributions import Beta
import config

class Actor(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.shared = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.ReLU(),
        )
        self.alpha_a_head = nn.Linear(64, 1)
        self.alpha_b_head = nn.Linear(64, 1)
        self.trend_a_head = nn.Linear(64, 1)
        self.trend_b_head = nn.Linear(64, 1)

    def forward(self, x, scale=1.0):
        h = self.shared(x)
        raw = torch.cat([
            self.alpha_a_head(h), self.alpha_b_head(h),
            self.trend_a_head(h), self.trend_b_head(h)
        ], dim=-1).clamp(-10.0, 10.0)
        a1, b1, a2, b2 = torch.chunk(raw, 4, dim=-1)
        # apply softplus and scale to concentration
        a1 = (nn.functional.softplus(a1) + 1.0) * scale
        b1 = (nn.functional.softplus(b1) + 1.0) * scale
        a2 = (nn.functional.softplus(a2) + 1.0) * scale
        b2 = (nn.functional.softplus(b2) + 1.0) * scale
        return torch.cat([a1, b1, a2, b2], dim=-1)

    def sample(self, params):
        a1, b1, a2, b2 = [p.squeeze(-1) for p in params.split(1, dim=-1)]
        # sanitize
        def safe(p): return torch.nan_to_num(p, nan=1.0, posinf=10.0, neginf=1.0).clamp(min=1e-3)
        a1, b1, a2, b2 = map(safe, (a1, b1, a2, b2))
        dist1 = Beta(a1, b1)
        dist2 = Beta(a2, b2)
        alpha_raw = dist1.rsample()       # in [0,1]
        trend_norm = dist2.rsample()      # in [0,1]
        return alpha_raw, trend_norm, dist1, dist2

class Critic(nn.Module):
    def __init__(self, state_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )
    def forward(self, x):
        return self.net(x)

class PPOAgent:
    def __init__(self,
                 state_dim, action_dim,
                 lr_actor, lr_critic,
                 gamma, K_epochs, eps_clip,
                 max_episodes,
                 max_scale=10.0):
        self.gamma = gamma
        self.K_epochs = K_epochs
        self.eps_clip = eps_clip
        self.max_episodes = max_episodes
        self.max_scale = max_scale
        self.current_ep = 0

        self.actor = Actor(state_dim, action_dim)
        self.critic = Critic(state_dim)
        self.opt_actor = optim.Adam(self.actor.parameters(), lr=lr_actor)
        self.opt_critic = optim.Adam(self.critic.parameters(), lr=lr_critic)
        self.memory = []

    def set_episode(self, ep):
        self.current_ep = ep

    def select_action(self, state):
        frac = self.current_ep / max(1, self.max_episodes - 1)
        scale = 1.0 + frac * (self.max_scale - 1.0)

        s = torch.FloatTensor(state).unsqueeze(0)
        with torch.no_grad():
            params = self.actor(s, scale=scale)
        alpha_raw, trend_norm, dist1, dist2 = self.actor.sample(params)

        # scale action
        trend = 3.0 + (45.0 - 3.0) * trend_norm
        action = torch.stack([alpha_raw, trend], dim=-1).squeeze(0)
        # logprob
        logprob = dist1.log_prob(alpha_raw).sum() + dist2.log_prob(trend_norm).sum()
        return action.cpu().numpy(), logprob.item()

    def store_transition(self, s, a, logp, r, s_, done):
        self.memory.append((s, a, logp, r, s_, done))

    def train(self):
        if not self.memory:
            return
        s, a, lp, r, ns, d = zip(*self.memory)
        states = torch.FloatTensor(np.stack(s))
        old_logps = torch.FloatTensor(lp).unsqueeze(1)
        rewards = torch.FloatTensor(r).unsqueeze(1)
        next_states = torch.FloatTensor(np.stack(ns))
        dones = torch.FloatTensor(d).unsqueeze(1)

        with torch.no_grad():
            values_next = self.critic(next_states)
            targets = rewards + self.gamma * values_next * (1 - dones)
            advantages = targets - self.critic(states)
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        for _ in range(self.K_epochs):
            frac = self.current_ep / max(1, self.max_episodes - 1)
            scale = 1.0 + frac * (self.max_scale - 1.0)
            params = self.actor(states, scale=scale)
            ar, tr, d1, d2 = self.actor.sample(params)
            trend = 3.0 + (45.0 - 3.0) * tr

            lp_a = d1.log_prob(ar).sum(dim=-1, keepdim=True)
            lp_t = d2.log_prob(tr).sum(dim=-1, keepdim=True)
            logps = lp_a + lp_t
            entropy = d1.entropy().mean() + d2.entropy().mean()

            ratios = torch.exp(logps - old_logps.detach())
            s1 = ratios * advantages
            s2 = torch.clamp(ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages
            loss_actor = -torch.min(s1, s2).mean() - 0.01 * entropy
            loss_critic = nn.MSELoss()(self.critic(states), targets)

            self.opt_actor.zero_grad()
            loss_actor.backward()
            self.opt_actor.step()
            self.opt_critic.zero_grad()
            loss_critic.backward()
            self.opt_critic.step()

        self.memory.clear()
