import os
import subprocess
import time
import random

from dtn_env import CdtnEnvContinuous
from ppo_agent import PPOAgent
import config
import utils

# 테스트할 에피소드 수
TEST_EPISODES = 100

# Buffer sizes to cycle through each episode (train과 동일한 값 사용)
BUFFER_SIZES = ["5M","10M","15M","20M","25M","30M", "35M", "40M", "45M", "50M"]

# Paths
CUR_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_SRC = os.path.dirname(CUR_DIR)

# Prepare Java classpath with the required JARs
LIB_DIR = os.path.join(PROJECT_SRC, 'lib')
jar_names = ['json.jar', 'ECLA.jar', 'DTNConsoleConnection.jar']
LIB_JARS = [os.path.join(LIB_DIR, name) for name in jar_names]
CP_SEP = ';' if os.name == 'nt' else ':'
CP = CP_SEP.join([PROJECT_SRC] + LIB_JARS)

# Base Java command for batch mode with a single run
BASE_JAVA_CMD = [
    'java',
    '-Xmx512M',
    '-cp', CP,
    'core.DTNSim',
    '-b', '1'
]

# Temporary override configuration file
OVERRIDE_CONF = os.path.join(PROJECT_SRC, 'override_settings.txt')


def main():
    # PPO agent 초기화 및 모델 로드
    agent = PPOAgent(
        config.STATE_DIM, config.ACTION_DIM,
        config.LR_ACTOR, config.LR_CRITIC,
        config.GAMMA, config.K_EPOCHS, config.EPS_CLIP,
        max_episodes=config.MAX_EPISODES,
        max_scale=10.0
    )
    utils.load_model(agent, 'ppo_dtn.pth')

    results = []  # (success_rate, total_reward, steps)

    for ep in range(1, TEST_EPISODES + 1):
        seed = random.randint(0, 10_000_000)
        buf_size = BUFFER_SIZES[(ep - 1) % len(BUFFER_SIZES)]

        # override settings 쓰기
        with open(OVERRIDE_CONF, 'w') as f:
            f.write(f"MovementModel.rngSeed = {seed}\n")
            f.write(f"Group.bufferSize = {buf_size}\n")

        # Java 시뮬레이터 실행
        java_cmd = BASE_JAVA_CMD + ['default_settings.txt', OVERRIDE_CONF]
        print(f"▶ Test Episode {ep} | seed={seed} | bufferSize={buf_size}")
        proc = subprocess.Popen(java_cmd, cwd=PROJECT_SRC)
        time.sleep(2)  # 소켓 오픈 대기

        # Gym 환경 초기화 및 에피소드 실행
        env = CdtnEnvContinuous()
        state = env.reset()
        total_reward = 0.0
        step_count = 0

        while True:
            action, _ = agent.select_action(state)
            state, reward, done, _ = env.step(action)
            total_reward += reward
            step_count += 1
            if done or step_count >= config.MAX_STEPS:
                break

        episode_success = state[2]  # 성공률
        print(f"✔ Test Episode {ep} done | success={episode_success:.3f} | steps={step_count} | total_reward={total_reward:.2f}\n")
        results.append((episode_success, total_reward, step_count))

        # Java 프로세스 종료 및 환경 종료
        proc.wait()
        env.close()

    # 테스트 결과 요약
    avg_success = sum(r[0] for r in results) / len(results)
    avg_reward = sum(r[1] for r in results) / len(results)
    avg_steps = sum(r[2] for r in results) / len(results)

    print(f"=== Test Summary over {TEST_EPISODES} episodes ===")
    print(f"Average success rate: {avg_success:.3f}")
    print(f"Average total reward: {avg_reward:.2f}")
    print(f"Average steps: {avg_steps:.1f}")


if __name__ == '__main__':
    main()
