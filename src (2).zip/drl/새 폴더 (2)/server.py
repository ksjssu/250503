import socket
import json
import numpy as np
import config
from ppo_agent import PPOAgent
import utils

# PPO Agent
agent = PPOAgent(config.STATE_DIM, config.ACTION_DIM,
                 lr_actor=config.LR_ACTOR, lr_critic=config.LR_CRITIC,
                 gamma=config.GAMMA, K_epochs=config.K_EPOCHS, eps_clip=config.EPS_CLIP)
utils.load_model(agent, "ppo_dtn.pth")
agent.actor.eval()

state_conn = None
action_conn = None

def start_state_server():
    global state_conn
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((config.HOST, 50051))
    server.listen(1)
    print("[Server] State server listening on port 50051")
    state_conn, _ = server.accept()
    print("[Server] State connection established.")
    buffer = ""
    while True:
        try:
            data = state_conn.recv(4096)
            if not data:
                break
            buffer += data.decode("utf-8")
            while '\n' in buffer:
                line, buffer = buffer.split('\n', 1)
                msg = json.loads(line.strip())
                print("[Server] Received state (raw):", msg)

                # 상태를 numpy 벡터로 변환
                state = np.array([
                    msg.get("buffer_occupancy", 0.0),
                    msg.get("message_count", 0.0),
                    msg.get("success_rate", 0.0)
                ], dtype=np.float32)
                print("[Server] Parsed state vector:", state)

                # 액션 전송
                if action_conn:
                    print("[DEBUG] ✅ Action connection exists. Creating action...")
                    action = agent.select_action(state, deterministic=True)
                    response = {
                        "action": [
                            float(np.clip(action[0], config.ALPHA_MIN, config.ALPHA_MAX)),
                            int(np.clip(action[1], config.TREND_MIN, config.TREND_MAX))
                        ]
                    }
                    msg_str = json.dumps(response) + "\n"
                    print("[DEBUG] Sending action:", msg_str.strip())
                    action_conn.sendall(msg_str.encode("utf-8"))
                else:
                    print("[Server] ⚠️ No action connection yet.")
        except Exception as e:
            print("[Server] State error:", e)
            break
    state_conn.close()

def start_action_server():
    import time
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((config.HOST, 50052))
    server.listen(1)
    print("[Server] Action server listening on port 50052")

    while True:
        try:
            print("[Server] waiting for action accept...")  # 추가
            server.settimeout(10)  # 최대 10초 기다리기
            conn, addr = server.accept()
            print("[Server] ✅ Action connection established from", addr)
            break
        except socket.timeout:
            print("[Server] ⚠️ Waiting for ActionReceiver to connect...")
            continue

    while True:
        try:
            dummy_state = np.zeros(config.STATE_DIM, dtype=np.float32)
            action = agent.select_action(dummy_state, deterministic=True)
            response = {
                "alpha": float(np.clip(action[0], config.ALPHA_MIN, config.ALPHA_MAX)),
                "trend_window": int(np.clip(action[1], config.TREND_MIN, config.TREND_MAX))
            }
            msg = json.dumps(response) + "\n"
            print("[Server] Sending action:", msg.strip())
            conn.sendall(msg.encode("utf-8"))
        except Exception as e:
            print("[Server] Action error:", e)
            break

    conn.close()


