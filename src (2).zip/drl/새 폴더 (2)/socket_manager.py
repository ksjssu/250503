import socket
import json

class StateSocket:
    def __init__(self, host, port):
        self.conn = self._connect(host, port)
    
    def _connect(self, host, port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((host, port))
        print(f"[Socket] ✅ Connected to state server at {host}:{port}")
        return s

    def receive_state(self):
        data = self.conn.recv(4096).decode('utf-8')
        msg = json.loads(data.strip())
        state = [msg["buffer_occupancy"], msg["message_count"], msg["success_rate"]]
        print("[Socket] ⬅️ Received state:", state)
        return state

    def close(self):
        self.conn.close()


class ActionSocket:
    def __init__(self, host, port):
        self.conn = self._connect(host, port)

    def _connect(self, host, port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((host, port))
        print(f"[Socket] ✅ Connected to action server at {host}:{port}")
        return s

    def send_action(self, action):
        action_msg = {
            "alpha": float(action[0]),
            "trend_window": int(action[1])
        }
        self.conn.sendall((json.dumps(action_msg) + "\n").encode("utf-8"))
        print("[Socket] ➡️ Sent action:", action_msg)

    def close(self):
        self.conn.close()
