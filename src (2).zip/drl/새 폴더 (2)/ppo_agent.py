# ppo_agent.py

import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Normal, Independent
import numpy as np
import config

class ActorNetwork(nn.Module):
    """Actor network that outputs the mean of a Gaussian policy for continuous actions."""
    def __init__(self, state_dim, action_dim, hidden_dim=64):
        super(ActorNetwork, self).__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc_mean = nn.Linear(hidden_dim, action_dim)
        # Log standard deviation parameters for each action dimension
        self.log_std_param = nn.Parameter(torch.zeros(action_dim))
        # Initialize weights
        nn.init.xavier_uniform_(self.fc1.weight)
        nn.init.xavier_uniform_(self.fc2.weight)
        nn.init.xavier_uniform_(self.fc_mean.weight)
        nn.init.constant_(self.fc1.bias, 0)
        nn.init.constant_(self.fc2.bias, 0)
        nn.init.constant_(self.fc_mean.bias, 0)

    def forward(self, state):
        x = torch.relu(self.fc1(state))
        x = torch.relu(self.fc2(x))
        mean = self.fc_mean(x)
        # (No activation on mean; actions will be clamped in environment if needed)
        return mean

    def get_dist(self, state):
        """
        Return a diagonal Gaussian action distribution for the given state.
        """
        mean = self.forward(state)
        # Convert log-std parameters to standard deviation
        std = torch.exp(self.log_std_param)  # shape: [action_dim]
        # Independent normal distribution for multi-dimensional action
        dist = Independent(Normal(mean, std), 1)
        return dist

class CriticNetwork(nn.Module):
    """Critic network that outputs the value (state-value estimate)."""
    def __init__(self, state_dim, hidden_dim=64):
        super(CriticNetwork, self).__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc_value = nn.Linear(hidden_dim, 1)  # outputs a single scalar value
        # Initialize weights
        nn.init.xavier_uniform_(self.fc1.weight)
        nn.init.xavier_uniform_(self.fc2.weight)
        nn.init.xavier_uniform_(self.fc_value.weight)
        nn.init.constant_(self.fc1.bias, 0)
        nn.init.constant_(self.fc2.bias, 0)
        nn.init.constant_(self.fc_value.bias, 0)

    def forward(self, state):
        x = torch.relu(self.fc1(state))
        x = torch.relu(self.fc2(x))
        value = self.fc_value(x)
        return value

class PPOAgent:
    """
    Proximal Policy Optimization agent with actor-critic networks.
    Handles action selection, trajectory storage, and policy updates.
    """
    def __init__(self, state_dim, action_dim, lr_actor, lr_critic, gamma, K_epochs, eps_clip):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.K_epochs = K_epochs
        self.eps_clip = eps_clip

        # Initialize Actor-Critic networks
        self.actor = ActorNetwork(state_dim, action_dim, hidden_dim=64)
        self.critic = CriticNetwork(state_dim, hidden_dim=64)
        # Optimizers for actor and critic
        self.optimizer_actor = optim.Adam(self.actor.parameters(), lr=lr_actor)
        self.optimizer_critic = optim.Adam(self.critic.parameters(), lr=lr_critic)

        # Device (GPU if available, else CPU)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.actor.to(self.device)
        self.critic.to(self.device)

        # Trajectory storage buffers
        self.states = []
        self.actions = []
        self.log_probs = []
        self.rewards = []
        self.is_terminals = []

    def select_action(self, state, deterministic=False):
        """
        Select an action given the state.
        If deterministic, returns the mean action (used for evaluation).
        If stochastic, samples from the policy distribution (used during training).
        """
        state = torch.tensor(state, dtype=torch.float32).to(self.device)
        if state.dim() == 1:
            state = state.unsqueeze(0)  # add batch dimension if needed
        dist = self.actor.get_dist(state)
        if deterministic:
            # Use mean of distribution for deterministic action
            action = dist.mean.detach().cpu().numpy()[0]
            return action.astype(np.float32)
        else:
            # Sample action from distribution for exploration
            action = dist.sample().detach()
            log_prob = dist.log_prob(action).detach()
            # Store state, action, log_prob for training
            self.states.append(state.cpu().numpy()[0])
            self.actions.append(action.cpu().numpy()[0])
            self.log_probs.append(log_prob.cpu().numpy())
            return action.cpu().numpy()[0].astype(np.float32)

    def store_transition(self, state, action, reward, next_state, done):
        """
        Store reward and done flag for the latest transition.
        (State and action have already been stored in select_action.)
        """
        self.rewards.append(reward)
        self.is_terminals.append(done)

    def _compute_returns_and_advantages(self):
        """
        Compute discounted returns and advantages for the collected trajectory.
        Uses Monte Carlo returns (no GAE).
        """
        returns = []
        discounted_sum = 0.0
        # Calculate returns from last to first
        for reward, is_terminal in zip(reversed(self.rewards), reversed(self.is_terminals)):
            if is_terminal:
                discounted_sum = 0.0
            discounted_sum = reward + self.gamma * discounted_sum
            returns.insert(0, discounted_sum)
        returns = torch.tensor(returns, dtype=torch.float32).to(self.device)
        # Normalize returns for stability
        returns = (returns - returns.mean()) / (returns.std() + 1e-7)
        # Compute advantages = returns - value estimates
        state_tensor = torch.tensor(np.array(self.states), dtype=torch.float32).to(self.device)
        values = self.critic(state_tensor).squeeze()
        advantages = returns - values.detach()
        # Normalize advantages
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-7)
        return returns, advantages

    def update(self):
        """
        Perform PPO update (actor and critic) over K_epochs using the trajectory in memory.
        """
        if len(self.states) == 0:
            return  # nothing to update

        # Prepare trajectory data as tensors
        old_states = torch.tensor(np.array(self.states), dtype=torch.float32).to(self.device)
        old_actions = torch.tensor(np.array(self.actions), dtype=torch.float32).to(self.device)
        old_log_probs = torch.tensor(np.array(self.log_probs), dtype=torch.float32).to(self.device)

        # Compute discounted returns and advantages
        returns, advantages = self._compute_returns_and_advantages()

        # PPO update for K epochs
        for _ in range(self.K_epochs):
            # Get distribution and value for current policy
            dist = self.actor.get_dist(old_states)
            new_log_probs = dist.log_prob(old_actions)
            entropy = dist.entropy().mean()
            state_values = self.critic(old_states).squeeze()

            # Calculate probability ratio (new / old)
            ratios = torch.exp(new_log_probs - torch.tensor(old_log_probs).to(self.device))
            # Compute surrogate losses
            surr1 = ratios * advantages
            surr2 = torch.clamp(ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages
            # Actor loss (maximize surrogate) with entropy bonus
            actor_loss = -torch.min(surr1, surr2).mean() - config.ENTROPY_COEF * entropy
            # Critic loss (value function MSE)
            critic_loss = nn.MSELoss()(state_values, returns)
            # Combine losses
            loss = actor_loss + 0.5 * critic_loss

            # Gradient descent step
            self.optimizer_actor.zero_grad()
            self.optimizer_critic.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.actor.parameters(), 0.5)
            nn.utils.clip_grad_norm_(self.critic.parameters(), 0.5)
            self.optimizer_actor.step()
            self.optimizer_critic.step()

        # Clear trajectory buffers after update
        self.states.clear()
        self.actions.clear()
        self.log_probs.clear()
        self.rewards.clear()
        self.is_terminals.clear()

    def train(self):
        """Alias for the update() method."""
        self.update()
