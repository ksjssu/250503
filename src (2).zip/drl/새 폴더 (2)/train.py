import gym
import config
from dtn_env import DtnEnv
from ppo_agent import PPOAgent

env = DtnEnv()
agent = PPOAgent(state_dim=3, action_dim=2, ...)  # 기존 하이퍼파라미터

for episode in range(config.MAX_EPISODES):
    state = env.reset()
    total_reward = 0.0

    for t in range(config.MAX_STEPS):
        action = agent.select_action(state)
        next_state, reward, done, _ = env.step(action)
        agent.store_transition(state, action, reward, next_state, done)

        state = next_state
        total_reward += reward
        if done:
            break

    agent.train()
    print(f"[Episode {episode}] Total Reward: {total_reward}")

agent.save("ppo_dtn.pth")
env.close()
