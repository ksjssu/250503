# test_ppo.py

import config
from dtn_env_continuous import CdtnEnvContinuous
from ppo_agent import PPOAgent
import utils
import subprocess

def launch_java_simulator():
    # Launch the Java ONE simulator (adjust command/path as needed)
    java_cmd = [
        "C:/Program Files/Java/jdk1.6.0_45/bin/java",
        "core.DTNSim", "-b", "1", "test_10.yaml"
    ]
    return subprocess.Popen(java_cmd)

def main():
    model_path = "ppo_dtn.pth"
    num_test_episodes = 5

    env = CdtnEnvContinuous(host=config.HOST, port=config.PORT)
    state_dim = config.STATE_DIM
    action_dim = config.ACTION_DIM
    agent = PPOAgent(state_dim, action_dim,
                     lr_actor=config.LR_ACTOR, lr_critic=config.LR_CRITIC,
                     gamma=config.GAMMA, K_epochs=config.K_EPOCHS, eps_clip=config.EPS_CLIP)
    utils.load_model(agent, model_path)
    agent.actor.eval()
    agent.critic.eval()

    for ep in range(1, num_test_episodes + 1):
        sim_process = launch_java_simulator()
        state = env.reset()
        done = False
        total_reward = 0.0
        while not done:
            action = agent.select_action(state, deterministic=True)
            state, reward, done, _ = env.step(action)
            total_reward += reward
        print(f"Test Episode {ep}: Total Reward = {total_reward:.2f}")
        sim_process.wait()
    env.close()

if __name__ == "__main__":
    main()
