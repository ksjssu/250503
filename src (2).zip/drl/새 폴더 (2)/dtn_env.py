import gym
import numpy as np
from socket_manager import StateSocket, ActionSocket
import json

class DtnEnv(gym.Env):
    def __init__(self, host='127.0.0.1', state_port=50051, action_port=50052):
        super(DtnEnv, self).__init__()
        self.state_socket = StateSocket(host, state_port)
        self.action_socket = ActionSocket(host, action_port)

        self.observation_space = gym.spaces.Box(low=0, high=1, shape=(3,), dtype=np.float32)
        self.action_space = gym.spaces.Box(low=np.array([0.0, 1]), high=np.array([1.0, 10]), dtype=np.float32)

    def reset(self):
        print("[ENV] Waiting for initial state from Java...")
        state = self.state_socket.receive_state()
        return np.array(state, dtype=np.float32)

    def step(self, action):
        print("[ENV] Sending action to Java:", action)
        self.action_socket.send_action(action)

        state = self.state_socket.receive_state()
        reward = 0.0  # reward는 Java가 전달 안 하면 추후 수정
        done = False
        return np.array(state, dtype=np.float32), reward, done, {}

    def close(self):
        self.state_socket.close()
        self.action_socket.close()
