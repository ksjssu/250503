# utils.py
import os
import torch
import matplotlib.pyplot as plt

def save_model(agent, filepath):
    """
    Save the actor and critic networks of the PPO agent to a file.
    """
    torch.save({
        'actor_state_dict': agent.actor.state_dict(),
        'critic_state_dict': agent.critic.state_dict()
    }, filepath)
    # Note: To load, the model architecture must be the same when instantiating the agent.

def load_model(agent, filepath="ppo_dtn.pth"):
    if not os.path.exists(filepath):
        print(f"[⚠️] 모델 체크포인트 {filepath} 없음. 새 모델로 시작합니다.")
        return
    checkpoint = torch.load(filepath, map_location=lambda storage, loc: storage)
    agent.actor.load_state_dict(checkpoint['actor_state_dict'])
    agent.critic.load_state_dict(checkpoint['critic_state_dict'])
    print(f"[📦] 모델 {filepath} 로드 완료.")

def plot_rewards(rewards, filename="rewards.png"):
    """
    Plot the reward curve over episodes and save to a PNG file.
    """
    plt.figure()
    plt.plot(rewards, label="Episode Reward")
    # Optionally plot a moving average for smoother curve
    if len(rewards) >= 50:
        import numpy as np
        mov_avg = np.convolve(rewards, np.ones(50)/50, mode='valid')
        plt.plot(range(49, 49+len(mov_avg)), mov_avg, label="Moving Average (50 episodes)")
    plt.xlabel("Episode")
    plt.ylabel("Total Reward")
    plt.title("Training Reward over Episodes")
    plt.legend()
    plt.savefig(filename)
    plt.close()
