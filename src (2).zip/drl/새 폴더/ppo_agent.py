# ppo_agent.py
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Normal, Independent
import numpy as np
import config

class ActorNetwork(nn.Module):
    """Neural network for the actor (policy) that outputs the mean of a Gaussian policy for continuous actions."""
    def __init__(self, state_dim, action_dim, hidden_dim=64):
        super(ActorNetwork, self).__init__()
        # Simple feed-forward neural network with two hidden layers
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        # Policy mean output
        self.fc_mean = nn.Linear(hidden_dim, action_dim)
        # Optional: define a separate parameter for log std of the action distribution
        self.log_std_param = nn.Parameter(torch.zeros(action_dim))  # learnable log std for each action dim

        # Weight initialization (optional): can initialize layers here if desired
        nn.init.xavier_uniform_(self.fc1.weight)
        nn.init.xavier_uniform_(self.fc2.weight)
        nn.init.xavier_uniform_(self.fc_mean.weight)
        nn.init.constant_(self.fc1.bias, 0)
        nn.init.constant_(self.fc2.bias, 0)
        nn.init.constant_(self.fc_mean.bias, 0)

    def forward(self, state):
        # Forward pass: compute action mean (policy mean)
        x = torch.relu(self.fc1(state))
        x = torch.relu(self.fc2(x))
        mean = self.fc_mean(x)
        # We do not apply activation on the mean output because we want it unbounded (will clamp actions in env if needed).
        # The standard deviation for the action distribution is derived from log_std_param (one per action dimension).
        return mean
    
    def get_dist(self, state):
        """
        Compute the action distribution (Gaussian) for a given state.
        Returns a torch.distributions.Independent distribution representing a diagonal Gaussian.
        """
        mean = self.forward(state)
        # Convert log_std_param to stddev
        std = torch.exp(self.log_std_param)  # shape [action_dim]
        # Create a Normal distribution for each action dimension, then make it independent (multivariate with diagonal covariance)
        dist = Independent(Normal(mean, std), 1)  # 1 indicates that last dimension (action dims) are treated as one event
        return dist


class CriticNetwork(nn.Module):
    """Neural network for the critic (value function) that outputs state-value estimates."""
    def __init__(self, state_dim, hidden_dim=64):
        super(CriticNetwork, self).__init__()
        # Simple feed-forward network for value estimation
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc_value = nn.Linear(hidden_dim, 1)  # outputs a single value

        # Weight initialization (optional)
        nn.init.xavier_uniform_(self.fc1.weight)
        nn.init.xavier_uniform_(self.fc2.weight)
        nn.init.xavier_uniform_(self.fc_value.weight)
        nn.init.constant_(self.fc1.bias, 0)
        nn.init.constant_(self.fc2.bias, 0)
        nn.init.constant_(self.fc_value.bias, 0)

    def forward(self, state):
        x = torch.relu(self.fc1(state))
        x = torch.relu(self.fc2(x))
        value = self.fc_value(x)
        return value  # no activation on value (it's unbounded)


class PPOAgent:
    """
    Proximal Policy Optimization (PPO) agent with actor-critic networks.
    Handles action selection, experience storage, and policy updates.
    """
    def __init__(self, state_dim, action_dim, lr_actor, lr_critic, gamma, K_epochs, eps_clip):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.K_epochs = K_epochs
        self.eps_clip = eps_clip

        # Initialize actor and critic networks
        self.actor = ActorNetwork(state_dim, action_dim, hidden_dim=64)
        self.critic = CriticNetwork(state_dim, hidden_dim=64)
        # Set up optimizers for actor and critic
        self.optimizer_actor = optim.Adam(self.actor.parameters(), lr=lr_actor)
        self.optimizer_critic = optim.Adam(self.critic.parameters(), lr=lr_critic)

        # Device (CPU or GPU)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.actor.to(self.device)
        self.critic.to(self.device)

        # Memory buffers for storing trajectories
        self.states = []
        self.actions = []
        self.log_probs = []
        self.rewards = []
        self.is_terminals = []  # to mark end of episode in trajectory (for multi-episode batch handling)

    def select_action(self, state, deterministic=False):
        """
        Given a state, select an action according to the current policy.
        If deterministic=True, returns the mean action (for evaluation).
        If deterministic=False, samples from the policy distribution (for exploration during training).
        """
        state = torch.tensor(state, dtype=torch.float32).to(self.device)
        if state.dim() == 1:  # add batch dimension if needed
            state = state.unsqueeze(0)
        # Get the action distribution from the actor
        dist = self.actor.get_dist(state)
        if deterministic:
            # For deterministic action, use the mean of the distribution
            action = dist.mean.detach().cpu().numpy()[0]
            # Do not record anything to memory if just evaluating
            return action.astype(np.float32)
        else:
            # Sample an action from the distribution
            action = dist.sample()
            action = action.detach()  # detach to avoid computing gradients through the sampling
            log_prob = dist.log_prob(action).detach()
            # Save state, action, log probability in buffers for later training
            # Store CPU numpy arrays or raw values to avoid GPU memory leaks for large buffers
            self.states.append(state.cpu().numpy()[0])    # store state
            self.actions.append(action.cpu().numpy()[0])  # store action
            self.log_probs.append(log_prob.cpu().numpy()) # store log probability
            # Return the sampled action (as numpy array for use in environment)
            return action.cpu().numpy()[0].astype(np.float32)

    def _compute_returns_and_advantages(self):
        """
        Compute discounted returns and advantages for the collected trajectory.
        Uses Monte Carlo estimate for returns (no GAE).
        Returns:
            returns (torch.Tensor), advantages (torch.Tensor)
        """
        returns = []
        discounted_sum = 0.0
        # Iterate from last step to first step to calculate discounted returns
        for reward, is_terminal in zip(reversed(self.rewards), reversed(self.is_terminals)):
            if is_terminal:
                # If episode ended here, reset the running sum for next episode segment
                discounted_sum = 0.0
            discounted_sum = reward + self.gamma * discounted_sum
            returns.insert(0, discounted_sum)
        returns = torch.tensor(returns, dtype=torch.float32).to(self.device)
        # Normalize returns for numerical stability (optional, can help training)
        returns = (returns - returns.mean()) / (returns.std() + 1e-7)

        # Compute advantages = returns - value_estimates
        # Get value estimates from critic for all states in trajectory
        state_tensor = torch.tensor(np.array(self.states), dtype=torch.float32).to(self.device)
        values = self.critic(state_tensor).squeeze()  # shape [batch]
        advantages = returns - values.detach()
        # Normalize advantages (optional but common in PPO)
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-7)
        return returns, advantages

    def update(self):
        """
        Perform a PPO policy update after collecting a trajectory (one or multiple episodes worth of experiences).
        Uses the collected states, actions, rewards, and log_probs stored in the buffers.
        """
        if len(self.states) == 0:
            return  # nothing to update

        # Convert collected trajectory data to torch tensors
        old_states = torch.tensor(np.array(self.states), dtype=torch.float32).to(self.device)
        old_actions = torch.tensor(np.array(self.actions), dtype=torch.float32).to(self.device)
        old_log_probs = torch.tensor(np.array(self.log_probs), dtype=torch.float32).to(self.device)

        # Compute returns and advantages for the trajectory
        returns, advantages = self._compute_returns_and_advantages()

        # PPO policy update for K epochs
        for _ in range(self.K_epochs):
            # Get probabilities and values from current policy
            dist = self.actor.get_dist(old_states)         # current policy distribution for all old states
            new_log_probs = dist.log_prob(old_actions)     # log probabilities of old actions under current policy
            entropy = dist.entropy().mean()                # entropy of policy for bonus (averaged over batch)
            state_values = self.critic(old_states).squeeze()

            # Compute ratio (pi_theta_new / pi_theta_old)
            # (We stored old log probs, so can compute exp(new_log - old_log))
            ratios = torch.exp(new_log_probs - old_log_probs)

            # Compute surrogate objectives
            surr1 = ratios * advantages
            surr2 = torch.clamp(ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages
            # Actor loss is negative of minimum of clipped/unclipped surrogate (negative for gradient ascent) 
            # minus an entropy bonus to encourage exploration
            actor_loss = -torch.min(surr1, surr2).mean() - config.ENTROPY_COEF * entropy
            # Critic loss is mean squared error between predicted state values and returns (ground-truth)
            critic_loss = nn.MSELoss()(state_values, returns)
            # Combine losses (note: could also optimize separately, here we do in one step for simplicity)
            total_loss = actor_loss + 0.5 * critic_loss

            # Take gradient step for actor-critic
            self.optimizer_actor.zero_grad()
            self.optimizer_critic.zero_grad()
            total_loss.backward()
            # Clip gradients to prevent explosion (optional)
            nn.utils.clip_grad_norm_(self.actor.parameters(), max_norm=0.5)
            nn.utils.clip_grad_norm_(self.critic.parameters(), max_norm=0.5)
            self.optimizer_actor.step()
            self.optimizer_critic.step()

        # Clear trajectory buffers after update
        self.states = []
        self.actions = []
        self.log_probs = []
        self.rewards = []
        self.is_terminals = []
