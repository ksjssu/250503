# train_ppo.py
import subprocess
import signal
import psutil
import socket
import threading
import time

from config import config
from dtn_env_continuous import CdtnEnvContinuous
from ppo_agent import PPOAgent
from server import run_server as start_state_server

# ------------------------
# 포트 사용 중이면 강제 종료
# ------------------------
def kill_port_process(port=5000):
    for conn in psutil.net_connections():
        if conn.laddr.port == port and conn.status == psutil.CONN_LISTEN:
            pid = conn.pid
            if pid:
                try:
                    psutil.Process(pid).terminate()
                except Exception:
                    subprocess.call(["taskkill", "/PID", str(pid), "/F"])

# ------------------------
# 자바 시뮬레이터 실행 함수
# ------------------------
def launch_java_simulator():
    java_cmd = [
        "C:/Program Files/Java/jdk1.6.0_45/bin/java",
        "-Xmx512M",
        "-cp", "../;../lib/ECLA.jar;../lib/DTNConsoleConnection.jar;../lib/json.jar",
        "core.DTNSim",
        "-b", "1",
        "../default_settings_randomwaypoint_final.txt"
    ]
    return subprocess.Popen(java_cmd)

# ------------------------
# 메인 PPO 루프
# ------------------------
def main():
    print("🔍 포트 정리 중...")
    kill_port_process(5000)
    kill_port_process(50051)
    kill_port_process(50052)

    print("🧠 PPO 학습 시작 전 환경 초기화")
    env = CdtnEnvContinuous(host="127.0.0.1", port=50052)
    agent = PPOAgent(state_size=env.state_size, action_size=env.action_size)
    all_episode_rewards = []

    print("🛰 상태 수신 서버(50051) 실행")
    threading.Thread(target=start_state_server, daemon=True).start()

    sim_process = None

    def cleanup(sig=None, frame=None):
        print("\n🛑 종료 감지: 자원 정리 중...")
        if sim_process:
            sim_process.terminate()
        env.close()
        kill_port_process(5000)
        kill_port_process(50051)
        kill_port_process(50052)
        exit(0)

    signal.signal(signal.SIGINT, cleanup)
    signal.signal(signal.SIGTERM, cleanup)

    try:
        for episode in range(1, config.MAX_EPISODES + 1):
            print(f"▶ Episode {episode} 시작: Java 시뮬레이터 실행 중...")
            sim_process = launch_java_simulator()

            # 학습 루프
            state = env.reset()
            episode_reward = 0

            for step in range(config.MAX_STEPS):
                action = agent.select_action(state)
                next_state, reward, done, _ = env.step(action)
                agent.store_transition(state, action, reward, next_state, done)

                state = next_state
                episode_reward += reward

                if done:
                    break

            agent.train()
            all_episode_rewards.append(episode_reward)

            print(f"✔️ Episode {episode} 완료 | 보상 합계: {episode_reward}")
            sim_process.wait()

    except KeyboardInterrupt:
        cleanup()

if __name__ == "__main__":
    main()
