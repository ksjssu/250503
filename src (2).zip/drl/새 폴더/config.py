# config.py
# Configuration constants for PPO training and DTN environment

# Learning rates
LR_ACTOR = 0.0003
LR_CRITIC = 0.001

# PPO hyperparameters
GAMMA = 0.99
K_EPOCHS = 4
EPS_CLIP = 0.2
ENTROPY_COEF = 0.01

# Training settings
MAX_EPISODES = 1000

# State and Action dimensions
STATE_DIM = 3
ACTION_DIM = 2

# Action bounds
ALPHA_MIN, ALPHA_MAX = 0.0, 1.0
TREND_MIN, TREND_MAX = 1.0, 100.0

# Communication
HOST = 'localhost'
PORT = 50052
PYTHON_SERVER_PORT = 50051

# Logging
PRINT_INTERVAL = 10
