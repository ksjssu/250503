# dtn_env_continuous.py
import gym
import numpy as np
import socket
import json
from gym import spaces
import config

class CdtnEnvContinuous(gym.Env):
    """
    Gym-compatible environment for a Continuous DTN (Delay Tolerant Network) simulator.
    This environment communicates with a Java-based ONE simulator via socket. Each step in this 
    environment corresponds to 30 units of time in the simulator's event log.
    
    State features may include metrics like average buffer occupancy, delivery predictability, etc.
    The action is a continuous 2D vector [ALPHA, trendWindow] that tunes the simulator's routing parameters.
    """
    metadata = {'render.modes': []}
    
    def __init__(self, host=None, port=None):
        super(CdtnEnvContinuous, self).__init__()
        # Use provided host/port or default from config
        self.host = host if host is not None else config.HOST
        self.port = port if port is not None else config.PORT

        # Setup server socket for simulator to connect
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Reuse address to avoid TIME_WAIT issues on restart
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(1)
        self.conn = None  # Will hold the active connection to simulator
        self._buffer = ""  # Buffer for incoming data assembly

        # Define action space (continuous) and observation space (will define after initial state if not known)
        # We clamp actions to specified ranges for safety.
        low  = np.array([config.ALPHA_MIN, config.TREND_MIN], dtype=np.float32)
        high = np.array([config.ALPHA_MAX, config.TREND_MAX], dtype=np.float32)
        self.action_space = spaces.Box(low=low, high=high, shape=(config.ACTION_DIM,), dtype=np.float32)

        # If state dimension is known from config, define observation space accordingly
        if config.STATE_DIM is not None:
            # Assuming state values are continuous in a reasonable range (e.g., 0.0 to 1.0 for ratios, counts normalized, etc.)
            obs_low = np.full((config.STATE_DIM,), -np.inf, dtype=np.float32)
            obs_high = np.full((config.STATE_DIM,), np.inf, dtype=np.float32)
            self.observation_space = spaces.Box(low=obs_low, high=obs_high, shape=(config.STATE_DIM,), dtype=np.float32)
        else:
            # If state dim is dynamic/unknown until runtime, we can set this later after receiving initial state.
            self.observation_space = None

        # Note: The ONE simulator should be configured to connect to this environment's socket and 
        # send state/reward at each step, then wait for an action response.
        print(f"[Env] Listening for simulator on {self.host}:{self.port}...")
    
    def _receive_message(self):
        """Internal helper to receive a complete JSON message from the simulator (blocking until message is received)."""
        # Loop until we have a full message (terminated by newline)
        while True:
            data = self.conn.recv(4096)
            if not data:
                # Connection closed unexpectedly
                raise ConnectionError("[Env] Simulator connection closed unexpectedly.")
            data = data.decode('utf-8')
            self._buffer += data
            # Check if we've received a full message (newline-terminated)
            if '\n' in self._buffer:
                line, self._buffer = self._buffer.split('\n', 1)
                # Parse the JSON line into a Python dict
                try:
                    message = json.loads(line)
                except json.JSONDecodeError as e:
                    raise ValueError(f"[Env] Failed to decode JSON from simulator: {e}")
                return message

    def reset(self):
        """
        Reset the environment at the start of an episode. 
        Waits for a connection from the simulator and receives the initial state.
        Returns:
            state (np.ndarray): The initial state observation from the simulator.
        """
        # If a previous connection exists (e.g., end of last episode), close it
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass
            self.conn = None

        # Accept a new connection from the simulator (this will block until the simulator connects)
        self.conn, addr = self.server_socket.accept()
        print(f"[Env] Simulator connected from {addr}")
        # Receive the initial state message from the simulator
        msg = self._receive_message()
        # The simulator is expected to send an initial state and initial reward (if any) at time 0
        state = msg.get('state', [])
        reward = msg.get('reward', 0.0)
        done = msg.get('done', False)
        # Convert state to numpy array
        state = np.array(state, dtype=np.float32)
        # If observation space was not defined (unknown state dim), define it now based on received state
        if self.observation_space is None:
            obs_low = np.full(state.shape, -np.inf, dtype=np.float32)
            obs_high = np.full(state.shape, np.inf, dtype=np.float32)
            self.observation_space = spaces.Box(low=obs_low, high=obs_high, shape=state.shape, dtype=np.float32)
        # Typically, done should be False on reset (episode just started)
        return state

    def step(self, action):
        """
        Send an action to the simulator and receive the next state and reward.
        Args:
            action (np.ndarray or list): The action to take (continuous values for ALPHA and trendWindow).
        Returns:
            next_state (np.ndarray), reward (float), done (bool), info (dict)
        """
        if self.conn is None:
            raise ConnectionError("[Env] No simulator connection. Call reset() before step().")

        # Ensure action is in a suitable format (e.g., numpy array or list of floats)
        action = np.array(action, dtype=float).flatten().tolist()
        # Clamp action values to the defined range for safety
        action[0] = float(np.clip(action[0], config.ALPHA_MIN, config.ALPHA_MAX))
        action[1] = float(np.clip(action[1], config.TREND_MIN, config.TREND_MAX))
        # Send the action to the simulator as a JSON message
        action_msg = {"action": action}
        try:
            self.conn.send((json.dumps(action_msg) + "\n").encode('utf-8'))
        except BrokenPipeError:
            raise ConnectionError("[Env] Failed to send action to simulator (connection broken).")
        
        # Receive the response from the simulator (next state and reward)
        msg = self._receive_message()
        next_state = msg.get('state', [])
        reward = msg.get('reward', 0.0)
        done = msg.get('done', False)
        # Convert next_state to numpy array for agent
        next_state = np.array(next_state, dtype=np.float32)
        # If episode is done, close the connection (simulator likely will disconnect as well)
        if done:
            # Close current connection (will reopen on next reset for new episode)
            try:
                self.conn.close()
            except Exception:
                pass
            self.conn = None
        # info dict can be used to return additional info; we leave it empty here
        return next_state, float(reward), bool(done), {}

    def close(self):
        """Clean up the environment by closing socket connections."""
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass
            self.conn = None
        if self.server_socket:
            try:
                self.server_socket.close()
            except Exception:
                pass
            self.server_socket = None
        print("[Env] Closed simulator connection and server socket.")
