# server.py
import socket
import json
import numpy as np
from ppo_agent import PPOAgent
import config
import utils

def run_server(model_path="ppo_dtn.pth"):
    # Load the trained PPO agent
    state_dim = config.STATE_DIM
    action_dim = config.ACTION_DIM
    agent = PPOAgent(state_dim, action_dim, 
                     lr_actor=config.LR_ACTOR, lr_critic=config.LR_CRITIC, 
                     gamma=config.GAMMA, K_epochs=config.K_EPOCHS, eps_clip=config.EPS_CLIP)
    utils.load_model(agent, model_path)
    agent.actor.eval()
    agent.critic.eval()
    print(f"[Server] Loaded trained model from {model_path}")

    # Set up socket server
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((config.HOST, 50051))  # 
    server_socket.listen(1)
    print(f"[Server] Listening on {config.HOST}:{config.PORT} for simulator connection...")

    try:
        while True:
            conn, addr = server_socket.accept()
            print(f"[Server] Simulator connected from {addr}")
            buffer = ""
            # Handle one simulation episode per connection
            while True:
                data = conn.recv(4096)
                if not data:
                    # Connection closed by simulator
                    print("[Server] Simulator disconnected.")
                    break
                buffer += data.decode('utf-8')
                if '\n' in buffer:
                    # Extract one full message (line) from buffer
                    line, buffer = buffer.split('\n', 1)
                    try:
                        msg = json.loads(line)
                    except json.JSONDecodeError as e:
                        print(f"[Server] JSON decode error: {e}")
                        continue
                    # Parse state and done flag from message
                    state = msg.get('state', [])
                    done = msg.get('done', False)
                    # (reward can be logged or used for analysis, but not needed to choose action)
                    reward = msg.get('reward', 0.0)
                    state = np.array(state, dtype=np.float32)
                    if done:
                        # If episode finished, no action needed, break out to await new connection
                        print("[Server] Received done=True from simulator, episode finished.")
                        break
                    # Compute action using the PPO agent (deterministic policy)
                    action = agent.select_action(state, deterministic=True)
                    # Clamp and prepare action for sending
                    action = np.array(action, dtype=float).flatten().tolist()
                    action[0] = float(np.clip(action[0], config.ALPHA_MIN, config.ALPHA_MAX))
                    action[1] = float(np.clip(action[1], config.TREND_MIN, config.TREND_MAX))
                    # Send action back to simulator as JSON
                    response = {"action": action}
                    try:
                        conn.send((json.dumps(response) + "\n").encode('utf-8'))
                    except BrokenPipeError:
                        print("[Server] Failed to send action (broken pipe).")
                        break
            conn.close()
            print("[Server] Connection closed. Waiting for new simulator connection...")
    finally:
        server_socket.close()
        print("[Server] Server socket closed.")

if __name__ == "__main__":
    run_server()
