from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import EvalCallback
from dtn_env_continuous import CdtnEnvContinuous
import os

def main():
    # 환경 생성
    env = CdtnEnvContinuous()

    # 모델 저장 경로
    save_path = "ppo_dtn"
    os.makedirs(save_path, exist_ok=True)

    # PPO 모델 생성 (기본 MLP 정책 사용)
    model = PPO(
        policy="MlpPolicy",
        env=env,
        verbose=1,
        tensorboard_log="./tensorboard_logs/"
    )

    # 콜백 설정 (정기적으로 평가 및 모델 저장)
    eval_callback = EvalCallback(
        env,
        best_model_save_path=save_path,
        log_path=save_path,
        eval_freq=5000,
        deterministic=True,
        render=False
    )

    # 학습 수행
    model.learn(
        total_timesteps=100_000,
        callback=eval_callback
    )

    # 모델 저장
    model.save(os.path.join(save_path, "ppo_dtn_final"))
    print("[Train] 학습 완료 및 모델 저장됨.")

    # 환경 종료
    env.close()

if __name__ == "__main__":
    main()
