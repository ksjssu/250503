import gym
from gym import spaces
import numpy as np
import socket
import json
import subprocess
import time
import os
import signal



class CdtnEnvContinuous(gym.Env):
    def __init__(self):
        super(CdtnEnvContinuous, self).__init__()

        # 액션: [alpha, trendWindow]
        self.action_space = spaces.Box(
            low=np.array([0.0, 1.0]),
            high=np.array([1.0, 100.0]),
            dtype=np.float32
        )

        # 상태: [buffer_occupancy, message_count, success_rate]
        self.observation_space = spaces.Box(
            low=0.0, high=1.0, shape=(3,), dtype=np.float32
        )

        self.sim_process = None
        self.state_socket = None
        self.action_socket = None
        self.state_conn = None
        self.action_conn = None

    def _launch_simulator(self):
        print("[Env] Launching Java simulator...")
        CREATE_NEW_PROCESS_GROUP = 0x00000200  # Windows 전용
        self.sim_process = subprocess.Popen(
		    ["java", "-jar", "dtnsim.jar"],
		    stdout=subprocess.PIPE,
		    stderr=subprocess.PIPE,
		    creationflags=CREATE_NEW_PROCESS_GROUP
		)
        time.sleep(3)  # 포트 열릴 때까지 대기

    def _setup_sockets(self):
        # 상태 수신 소켓 (50051)
        state_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        state_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        state_sock.bind(('localhost', 50051))
        state_sock.listen(1)
        print("[Env] Waiting for state socket connection (50051)...")
        self.state_conn, _ = state_sock.accept()
        print("[Env] State socket connected.")
        self.state_socket = state_sock

        # 액션 송신 소켓 (50052)
        action_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        action_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        action_sock.bind(('localhost', 50052))
        action_sock.listen(1)
        print("[Env] Waiting for action socket connection (50052)...")
        self.action_conn, _ = action_sock.accept()
        print("[Env] Action socket connected.")
        self.action_socket = action_sock

    def reset(self):
        # 이전 프로세스 정리
        self._terminate_simulator()

        # 시뮬레이터 실행 및 소켓 연결
        self._launch_simulator()
        self._setup_sockets()

        # 초기 상태 수신
        state_json = self.state_conn.recv(1024).decode()
        state = json.loads(state_json)

        self.current_state = np.array([
            state["buffer_occupancy"],
            state["message_count"] / 100.0,
            state["success_rate"]
        ], dtype=np.float32)
        self.current_event_step = state.get("event_step", 0)

        return self.current_state

    def step(self, action):
        # 액션 전송
        action_data = {
            "alpha": float(np.clip(action[0], 0.0, 1.0)),
            "trendWindow": int(np.clip(action[1], 1, 100))
        }
        self.action_conn.send(json.dumps(action_data).encode())
        print(f"[Env] Sent action: {action_data}")

        # 다음 상태 수신
        state_json = self.state_conn.recv(1024).decode()
        if not state_json:
            print("[Env] Simulator closed connection.")
            return self.current_state, 0.0, True, {}

        state = json.loads(state_json)
        print(f"[Env] Received state: {state}")

        next_state = np.array([
            state["buffer_occupancy"],
            state["message_count"] / 100.0,
            state["success_rate"]
        ], dtype=np.float32)

        reward = self._calculate_reward(state)
        done = state.get("event_step", 0) >= 10000  # 종료 조건

        self.current_state = next_state
        return next_state, reward, done, {}

    def _calculate_reward(self, state):
        return state["success_rate"] - 0.05 * state["buffer_occupancy"]

    def _terminate_simulator(self):
        if self.sim_process is not None:
            print("[Env] Terminating previous simulator...")
            try:
                os.killpg(os.getpgid(self.sim_process.pid), signal.SIGTERM)
                self.sim_process.wait()
            except Exception as e:
                print(f"[Env] Error terminating simulator: {e}")
            self.sim_process = None

        if self.state_conn:
            self.state_conn.close()
        if self.action_conn:
            self.action_conn.close()
        if self.state_socket:
            self.state_socket.close()
        if self.action_socket:
            self.action_socket.close()

        self.state_conn = None
        self.action_conn = None
        self.state_socket = None
        self.action_socket = None

    def close(self):
        self._terminate_simulator()
        print("[Env] Environment closed.")

