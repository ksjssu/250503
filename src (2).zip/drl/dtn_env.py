import socket
import json
import numpy as np
import config
import gym
from gym import spaces

class CdtnEnvContinuous(gym.Env):
    def __init__(self):
        super(CdtnEnvContinuous, self).__init__()
        # STATE channel
        self.state_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.state_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.state_sock.bind((config.HOST, config.STATE_PORT))
        self.state_sock.listen(1)
        print(f"[Socket][PY] Listening for STATE on {config.HOST}:{config.STATE_PORT}")
        self.state_conn, addr = self.state_sock.accept()
        print(f"[Socket][PY] ✅ STATE connection accepted from {addr}")

        # ACTION channel
        self.action_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.action_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.action_sock.bind((config.HOST, config.ACTION_PORT))
        self.action_sock.listen(1)
        print(f"[Socket][PY] Listening for ACTION on {config.HOST}:{config.ACTION_PORT}")
        self.action_conn, addr = self.action_sock.accept()
        print(f"[Socket][PY] ✅ ACTION connection accepted from {addr}")

        self.observation_space = spaces.Box(
            low=0.0, high=1.0,
            shape=(config.STATE_DIM,), dtype=np.float32
        )
        # trend_window 최대값을 30으로 제한
        self.action_space = spaces.Box(
            low=np.array([0.0, 3.0], dtype=np.float32),
            high=np.array([1.0, 100.0], dtype=np.float32),
            dtype=np.float32
        )
        self.state = None

    def _recv_line(self, conn):
        data = b""
        while not data.endswith(b"\n"):
            chunk = conn.recv(1024)
            if not chunk:
                break
            data += chunk
        return data.decode().strip()

    def _receive_state(self):
        line = self._recv_line(self.state_conn)
        if not line:
            return None
        if line == "done":
            return "done"
        try:
            msg = json.loads(line)
            # 새로운 상태값들 처리
            delivery_prob = msg.get("delivery_prob", 0.0)      # 전달확률
            avg_buffer_occ = msg.get("avg_buffer_occupancy", 0.0)  # 평균 버퍼 점유율
            avg_energy = msg.get("avg_energy", 0.0)            # 평균 에너지
            drop_rate = msg.get("drop_rate", 0.0)             # 드롭율
            failure_rate = msg.get("failure_rate", 0.0)        # 실패율
            
            state = np.array([
                delivery_prob,
                avg_buffer_occ / config.MAX_BUFFER_OCCUPANCY,
                avg_energy / config.MAX_ENERGY,
                drop_rate,
                failure_rate
            ], dtype=np.float32)
            
            print(f"[Socket][PY] Received STATE: {state}")
            return state
        except json.JSONDecodeError:
            print(f"[Socket][PY] JSON decode error: {line}")
            return None

    def _send_action(self, action):
                # trend_window는 반올림해서 자연수로
        tw = int(round(action[1]))
        # 혹시 round 후 경계 밖으로 나가지 않도록 확실히 클립
        tw = max(3, min(100, tw))
        msg = {"alpha": float(action[0]), "trend_window": tw}
        payload = json.dumps(msg) + "\n"
        self.action_conn.sendall(payload.encode())
        print(f"[Socket][PY] Sent ACTION to Java: {msg}")

    def reset(self):
        self.state = self._receive_state()
        print(f"[Socket][PY] reset() got state: {self.state}")
        return self.state

    def step(self, action):
        action = np.clip(action, self.action_space.low, self.action_space.high)
        self._send_action(action)
        next_state = self._receive_state()

        # handle termination signal
        if isinstance(next_state, str) and next_state == "done":
            print(f"[Socket][PY] Received 'done' signal, ending step.")
            final_delivery_prob = self.state[0]  # 마지막 상태의 전달 확률
            terminal_reward = final_delivery_prob * 10.0  # 예: 10배 가중치
            return self.state, terminal_reward, True, {}
        
        if next_state is None:
            print(f"[Socket][PY] Received None state, ending step.")
            return self.state, 0.0, True, {}
            
        delivery_prob, avg_buffer_occ, avg_energy, drop_rate, failure_rate = next_state
        
        # 일반적인 스텝에서의 보상
        reward = (
            delivery_prob                    
            - 0.01 * avg_buffer_occ         
            - 0.1 * drop_rate               
            - 0.1 * failure_rate            
            + 0.01 * avg_energy             
        )
        
        self.state = next_state
        return next_state, reward, False, {}

    def close(self):
        self.state_conn.close()
        self.state_sock.close()
        self.action_conn.close()
        self.action_sock.close()
        print("[Socket][PY] Closed STATE and ACTION sockets.")
